self.addEventListener("push", (event) => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch (_) {}
  const title = data.title || "PAWON SEE T";
  const options = {
    body: data.body || "Ada pengingat pesanan catering.",
    icon: "./favicon.svg",
    badge: "./favicon.svg",
    tag: data.tag || "pawon-see-t-reminder",
    data: { url: data.url || "./?page=calendar" },
    renotify: false,
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const target = event.notification.data?.url || "./?page=calendar";
  event.waitUntil((async () => {
    const destination = new URL(target, self.registration.scope).href;
    const clientsList = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    for (const client of clientsList) {
      if ("focus" in client) {
        await client.navigate(destination);
        return client.focus();
      }
    }
    return self.clients.openWindow(destination);
  })());
});

self.addEventListener("install", (event) => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));
