# PAWON SEE T

Website admin catering yang dibuat dengan React, Vite, dan Supabase. Halaman pertama adalah kalender bulanan; tanggal yang memiliki pesanan ditandai maroon.

## Fitur
- Kalender bulanan sebagai dashboard awal, dengan lingkaran maroon pada tanggal yang memiliki pesanan.
- Detail pesanan per tanggal: jumlah pesanan, total box, dan nilai pesanan.
- Tambah, edit, dan pembatalan pesanan secara manual.
- Satu pesanan dapat memiliki beberapa kelompok menu dan jumlah box yang berbeda.
- Paket A/B/C dengan isi yang bisa diatur.
- Menu dan harga per porsi yang bisa ditambah, diubah, atau dinonaktifkan.
- Riwayat pembayaran; status DP dan lunas dihitung dari pembayaran yang dicatat.
- Nota PNG dengan logo, Facebook, Instagram, nomor HP, alamat, watermark, tabel menu, Total, DP, dan Sisa.
- Laporan harian, mingguan, bulanan, tahunan, dan rentang tanggal pilihan.
- Pengingat H-2 untuk pesanan belum DP dan H-1 untuk pesanan besok.
- Notifikasi push browser pada perangkat admin.
- Zona waktu Asia/Jakarta.

## Menjalankan di komputer
1. Install Node.js 22 atau lebih baru.
2. Ekstrak ZIP.
3. Buka folder proyek lalu jalankan:
   ```bash
   npm install
   npm run dev
   ```
4. Buka alamat lokal yang ditampilkan Vite.

Supabase URL dan publishable key sudah dipasang di `src/lib/supabase.js`. Publishable key memang ditujukan untuk aplikasi browser. Jangan pernah memasukkan `service_role` atau secret key ke frontend.

## Login admin pertama kali
1. Pilih **Daftar akun** dan buat akun menggunakan email admin.
2. Jika Supabase meminta konfirmasi email, buka email konfirmasi terlebih dahulu.
3. Masuk menggunakan akun tersebut.
4. Masukkan kode undangan admin yang diberikan secara pribadi oleh pemilik.
5. Kode undangan yang disiapkan untuk workspace ini dapat dipakai maksimal 2 akun admin (misalnya admin utama dan Bunda). Jangan unggah atau menuliskan kode undangan ke repository publik.

Jika konfirmasi email aktif, tambahkan URL website GitHub Pages pada Supabase Dashboard → Authentication → URL Configuration → Redirect URLs. Tambahkan juga `http://localhost:5173/**` untuk pengujian lokal.

## Hosting sementara di GitHub Pages
1. Buat repository GitHub baru, misalnya `pawon-see-t`.
2. Upload seluruh isi folder ZIP ini ke branch `main` (bukan folder ZIP-nya).
3. Buka **Settings → Pages** di repository.
4. Pada bagian Build and deployment, pilih **GitHub Actions**.
5. Workflow `.github/workflows/deploy.yml` akan membangun dan menerbitkan website setiap kali ada push ke `main`.
6. Setelah workflow selesai, buka URL GitHub Pages yang diberikan GitHub.
7. Tambahkan URL tersebut ke Supabase Authentication → URL Configuration → Redirect URLs.

## Pengingat otomatis
Supabase Edge Function `send-pawon-reminders` dan jadwal Cron sudah tersedia pada project Pawon See T. Jadwal berjalan setiap 5 menit dan mengirim pengingat setelah jam yang dipilih pada Pengaturan (default 09.00 WIB). Agar notifikasi muncul di HP, buka website melalui HTTPS (GitHub Pages), masuk sebagai admin, lalu pilih Pengaturan → Aktifkan notifikasi.

## Catatan database
Website menggunakan tabel yang sudah ada di project Supabase Pawon See T: `workspaces`, `workspace_members`, `customers`, `menu_items`, `packages`, `package_items`, `orders`, `order_groups`, `order_items`, `payments`, `order_history`, `app_settings`, `notification_events`, dan `push_subscriptions`.

Perubahan identitas nota tersimpan di `app_settings`. Semua pesanan menggunakan RPC `save_order_bundle` agar header pesanan, kelompok menu, dan item disimpan sebagai satu proses.

## Keamanan
- Semua akses data bisnis berjalan setelah admin login dan melewati Row Level Security.
- Jangan menaruh service role key di frontend.
- Project saat ini memiliki advisory Supabase terkait tabel `private.workspace_invites` yang RLS-nya belum aktif. Jangan aktifkan RLS tanpa menyiapkan kebijakan yang sesuai karena fungsi klaim undangan yang aman mengakses tabel tersebut. Tinjau advisory sebelum aplikasi dipakai untuk data produksi.
