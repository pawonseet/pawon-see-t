-- Applied to the connected Pawon See T Supabase project.
-- This file is retained in the repository so the project schema is documented.
alter table public.app_settings
  add column if not exists business_name text not null default 'PAWON SEE T',
  add column if not exists business_phone text default '0895-8033-15353',
  add column if not exists business_address text default 'JL KAPUK RAYA PASAR DARURAT, RT 5 RW 12 GG HJ SABERIN NO. 142, KAPUK, CENGKARENG, JAKARTA BARAT',
  add column if not exists facebook_handle text default 'Pawon.see_t',
  add column if not exists instagram_handle text default 'Pawon.see_t',
  add column if not exists invoice_footer text default 'Terima Kasih Atas Pesanan Anda';
