import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.119.0";
import webpush from "npm:web-push@3.6.7";

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const admin = createClient(supabaseUrl, serviceRoleKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});

function dateInTimezone(timeZone: string): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone, year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(new Date());
  const p = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${p.year}-${p.month}-${p.day}`;
}
function addDays(ymd: string, days: number): string {
  const [year, month, day] = ymd.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + days));
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${String(date.getUTCDate()).padStart(2, "0")}`;
}
function timeInTimezone(timeZone: string): string {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone, hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  }).format(new Date());
}
function shortDate(ymd: string, timeZone: string): string {
  const [year, month, day] = ymd.split("-").map(Number);
  return new Intl.DateTimeFormat("id-ID", {
    timeZone, day: "numeric", month: "short",
  }).format(new Date(Date.UTC(year, month - 1, day, 5)));
}

async function sendToWorkspace(
  workspaceId: string,
  notificationDate: string,
  notificationType: "tomorrow_orders" | "pending_dp",
  title: string,
  body: string,
  orderCount: number,
  totalBoxes: number,
  url: string,
) {
  const { data: existing, error: existingError } = await admin
    .from("notification_events").select("id")
    .eq("workspace_id", workspaceId)
    .eq("notification_date", notificationDate)
    .eq("notification_type", notificationType)
    .maybeSingle();
  if (existingError) throw existingError;
  if (existing) return { skipped: true, reason: "already_sent" };

  const { data: subscriptions, error: subError } = await admin
    .from("push_subscriptions").select("id, endpoint, p256dh, auth_secret")
    .eq("workspace_id", workspaceId).eq("is_active", true);
  if (subError) throw subError;
  if (!subscriptions?.length) return { skipped: true, reason: "no_subscriptions" };

  const payload = JSON.stringify({ title, body, url, tag: `${notificationType}-${notificationDate}` });
  let sent = 0;
  let retryNeeded = false;

  for (const sub of subscriptions) {
    try {
      await webpush.sendNotification(
        { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth_secret } },
        payload,
      );
      sent++;
    } catch (error) {
      const statusCode = (error as { statusCode?: number })?.statusCode;
      if (statusCode === 404 || statusCode === 410) {
        const { error: deactivateError } = await admin
          .from("push_subscriptions").update({ is_active: false }).eq("id", sub.id);
        if (deactivateError) throw deactivateError;
      } else {
        retryNeeded = true;
        console.error("Push delivery failed; will retry", { subscriptionId: sub.id, statusCode, error: String(error) });
      }
    }
  }

  if (sent > 0 && !retryNeeded) {
    const { error: logError } = await admin.from("notification_events").insert({
      workspace_id: workspaceId, notification_date: notificationDate,
      notification_type: notificationType, title, body,
      order_count: orderCount, total_boxes: totalBoxes, sent_at: new Date().toISOString(),
    });
    if (logError && !String(logError.message).toLowerCase().includes("duplicate")) throw logError;
  }
  return { sent, subscriptions: subscriptions.length, retry_scheduled: retryNeeded };
}

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  try {
    const { data: config, error: configError } = await admin.rpc("get_pawon_push_config");
    if (configError) throw configError;
    if (!config?.pawon_cron_secret || req.headers.get("x-pawon-cron-secret") !== config.pawon_cron_secret) {
      return new Response("Unauthorized", { status: 401 });
    }
    if (!config.pawon_vapid_public_key || !config.pawon_vapid_private_key || !config.pawon_vapid_subject) {
      throw new Error("VAPID settings are incomplete in Supabase Vault.");
    }
    webpush.setVapidDetails(config.pawon_vapid_subject, config.pawon_vapid_public_key, config.pawon_vapid_private_key);

    const { data: workspaces, error: workspaceError } = await admin.from("workspaces").select("id, timezone");
    if (workspaceError) throw workspaceError;
    const results: unknown[] = [];

    for (const workspace of workspaces || []) {
      const timeZone = workspace.timezone || "Asia/Jakarta";
      const today = dateInTimezone(timeZone);
      const tomorrow = addDays(today, 1);
      const dayAfterTomorrow = addDays(today, 2);
      const currentTime = timeInTimezone(timeZone);

      const { data: settings, error: settingsError } = await admin
        .from("app_settings")
        .select("notification_time, reminder_tomorrow_enabled, reminder_pending_dp_enabled")
        .eq("workspace_id", workspace.id).maybeSingle();
      if (settingsError) throw settingsError;
      const sendAfter = String(settings?.notification_time || "09:00:00").slice(0, 5);
      if (currentTime < sendAfter) continue;

      if (settings?.reminder_tomorrow_enabled !== false) {
        const { data: tomorrowOrders, error: tomorrowError } = await admin
          .from("orders").select("id, box_count")
          .eq("workspace_id", workspace.id).eq("event_date", tomorrow)
          .neq("confirmation_status", "cancelled");
        if (tomorrowError) throw tomorrowError;
        if (tomorrowOrders?.length) {
          const count = tomorrowOrders.length;
          const boxes = tomorrowOrders.reduce((sum, order) => sum + Number(order.box_count || 0), 0);
          const body = `Besok ada ${count} pesanan catering, total ${boxes} box!`;
          const result = await sendToWorkspace(
            workspace.id, today, "tomorrow_orders", "PAWON SEE T", body,
            count, boxes, `./?page=calendar&date=${tomorrow}`,
          );
          results.push({ workspace: workspace.id, type: "tomorrow_orders", ...result });
        }
      }

      if (settings?.reminder_pending_dp_enabled !== false) {
        const { data: pendingOrders, error: pendingError } = await admin
          .from("orders").select("id, box_count")
          .eq("workspace_id", workspace.id).eq("event_date", dayAfterTomorrow)
          .eq("confirmation_status", "awaiting_dp");
        if (pendingError) throw pendingError;
        if (pendingOrders?.length) {
          const count = pendingOrders.length;
          const boxes = pendingOrders.reduce((sum, order) => sum + Number(order.box_count || 0), 0);
          const body = count === 1
            ? `Ada pesanan yang belum DP untuk acara ${shortDate(dayAfterTomorrow, timeZone)}.`
            : `Ada ${count} pesanan yang belum DP untuk acara ${shortDate(dayAfterTomorrow, timeZone)}.`;
          const result = await sendToWorkspace(
            workspace.id, today, "pending_dp", "Pengingat DP · PAWON SEE T",
            body, count, boxes, "./?page=reminders",
          );
          results.push({ workspace: workspace.id, type: "pending_dp", ...result });
        }
      }
    }

    return new Response(JSON.stringify({ ok: true, results }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Pawon See T reminder error", error);
    return new Response(JSON.stringify({ ok: false, error: String(error) }), {
      status: 500, headers: { "Content-Type": "application/json" },
    });
  }
});
