import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import html2canvas from "html2canvas";
import {
  AlertCircle, ArrowLeft, BarChart3, Bell, BellRing, CalendarDays,
  Check, CheckCircle2, ChefHat, ChevronLeft, ChevronRight, CircleDollarSign,
  ClipboardList, Clock3, CreditCard, Download, Edit3, FileText, Filter,
  Home, Instagram, LogOut, Mail, MapPin, Menu as MenuIcon, MoreHorizontal,
  Package, Phone, Plus, ReceiptText, RefreshCw, Save, Search, Settings,
  SlidersHorizontal, Truck, Utensils, Wallet, X
} from "lucide-react";
import { supabase } from "./lib/supabase";

const WORKSPACE_SLUG = "pawon-see-t";
const TIME_ZONE = "Asia/Jakarta";
const VAPID_PUBLIC_KEY = "BA47Ew9tpRAbTUEMh4-yHRSrYtBQ_uq1U4t6wYVbm-9DDLMVZ4HWhI5etQXgUKm9AdA2IFsQk7ITRWhbPGLlnK4";

const DEFAULT_SETTINGS = {
  business_name: "PAWON SEE T",
  business_phone: "0895-8033-15353",
  business_address: "JL KAPUK RAYA PASAR DARURAT, RT 5 RW 12 GG HJ SABERIN NO. 142, KAPUK, CENGKARENG, JAKARTA BARAT",
  facebook_handle: "Pawon.see_t",
  instagram_handle: "Pawon.see_t",
  invoice_footer: "Terima Kasih Atas Pesanan Anda",
  timezone: TIME_ZONE,
  notification_time: "09:00",
  reminder_tomorrow_enabled: true,
  reminder_pending_dp_enabled: true,
};

const money = (value) =>
  new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0,
  }).format(Number(value || 0));

const numberFormat = (value) => new Intl.NumberFormat("id-ID").format(Number(value || 0));

function jakartaToday() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TIME_ZONE, year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(new Date());
  const p = Object.fromEntries(parts.map((x) => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}`;
}

function addDays(ymd, amount) {
  const [y, m, d] = ymd.split("-").map(Number);
  const date = new Date(Date.UTC(y, m - 1, d + amount, 12));
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${String(date.getUTCDate()).padStart(2, "0")}`;
}

function formatDate(ymd, options = { day: "numeric", month: "long", year: "numeric" }) {
  if (!ymd) return "—";
  const [y, m, d] = ymd.split("-").map(Number);
  return new Intl.DateTimeFormat("id-ID", { ...options, timeZone: TIME_ZONE })
    .format(new Date(Date.UTC(y, m - 1, d, 5)));
}

function dateFromTimestamp(value) {
  if (!value) return "";
  const date = new Date(value);
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TIME_ZONE, year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(date);
  const p = Object.fromEntries(parts.map((x) => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}`;
}

function dateRangeFor(preset, today) {
  const [y, m, d] = today.split("-").map(Number);
  if (preset === "today") return [today, today];
  if (preset === "week") {
    const weekday = new Date(Date.UTC(y, m - 1, d, 12)).getUTCDay();
    const mondayOffset = weekday === 0 ? -6 : 1 - weekday;
    const start = addDays(today, mondayOffset);
    return [start, addDays(start, 6)];
  }
  if (preset === "year") return [`${y}-01-01`, `${y}-12-31`];
  return [`${y}-${String(m).padStart(2, "0")}-01`, `${y}-${String(m).padStart(2, "0")}-${new Date(Date.UTC(y, m, 0)).getUTCDate()}`];
}

function orderBoxes(order) {
  if (order?.groups?.length) return order.groups.reduce((sum, group) => sum + Number(group.box_count || 0), 0);
  return Number(order?.box_count || 0);
}

function orderTotal(order) {
  const groupsTotal = (order?.groups || []).reduce(
    (sum, group) => sum + Number(group.box_count || 0) * Number(group.base_price_per_box || 0),
    0
  );
  const base = groupsTotal || (Number(order?.box_count || 0) * Number(order?.base_price_per_box || 0));
  return Math.max(0, base + Number(order?.delivery_fee || 0) - Number(order?.discount_amount || 0));
}

function paidTotal(order) {
  return (order?.payments || []).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function outstanding(order) {
  return Math.max(0, orderTotal(order) - paidTotal(order));
}

function paymentLabel(order) {
  if (order?.confirmation_status === "cancelled") return "Dibatalkan";
  const paid = paidTotal(order);
  if (paid <= 0) return "Belum DP";
  if (paid >= orderTotal(order)) return "Lunas";
  return "Sudah DP";
}

function prepLabel(status) {
  return ({
    not_started: "Belum diproses",
    preparing: "Diproses",
    ready: "Siap",
    completed: "Selesai",
  })[status] || "Belum diproses";
}

function menuSummary(order) {
  const names = [];
  (order?.groups || []).forEach((group) => {
    (group.items || []).forEach((item) => {
      if (item.item_name && !names.includes(item.item_name)) names.push(item.item_name);
    });
  });
  return names.join(", ");
}

function getMonthDays(monthDate) {
  const year = monthDate.getFullYear();
  const month = monthDate.getMonth();
  const firstDay = new Date(Date.UTC(year, month, 1, 12)).getUTCDay();
  const total = new Date(Date.UTC(year, month + 1, 0, 12)).getUTCDate();
  return [...Array(firstDay).fill(null), ...Array.from({ length: total }, (_, i) => i + 1)];
}

function buildGroupFromOrder(group) {
  return {
    localId: group.id || crypto.randomUUID(),
    packageId: group.package_id || "",
    boxCount: String(group.box_count || 1),
    items: (group.items || []).map((item) => ({
      menu_item_id: item.menu_item_id || "",
      item_name: item.item_name,
      unit_price: Number(item.unit_price || 0),
      quantity_per_box: Number(item.quantity_per_box || 1),
      charge_type: item.charge_type || "per_box",
      is_included: Boolean(item.is_included),
      notes: item.notes || "",
    })),
  };
}

function priceForGroup(group, packages) {
  const pack = packages.find((p) => p.id === group.packageId);
  const included = group.items.filter((i) => i.is_included);
  const extras = group.items.filter((i) => !i.is_included);
  if (pack && Number(pack.base_price_per_box || 0) > 0) {
    return Number(pack.base_price_per_box) + extras.reduce((s, i) => s + Number(i.unit_price || 0) * Number(i.quantity_per_box || 1), 0);
  }
  return group.items.reduce((s, i) => s + Number(i.unit_price || 0) * Number(i.quantity_per_box || 1), 0);
}

function groupPayload(group, packages, index) {
  const pack = packages.find((p) => p.id === group.packageId);
  return {
    package_id: group.packageId || null,
    package_name_snapshot: pack?.name || null,
    box_count: Number(group.boxCount || 0),
    base_price_per_box: priceForGroup(group, packages),
    sort_order: index,
    items: group.items.map((item, itemIndex) => ({
      menu_item_id: item.menu_item_id || null,
      item_name: item.item_name,
      unit_price: Number(item.unit_price || 0),
      quantity_per_box: Number(item.quantity_per_box || 1),
      charge_type: item.charge_type || "per_box",
      is_included: Boolean(item.is_included),
      notes: item.notes || null,
      sort_order: itemIndex,
    })),
  };
}

function BrandMark({ watermark = false, settings = DEFAULT_SETTINGS }) {
  return (
    <div className={`brand-mark ${watermark ? "brand-mark-watermark" : ""}`}>
      <svg className="brand-ornament" viewBox="0 0 340 170" aria-hidden="true">
        <path d="M40 92 C45 28 100 8 170 8 C240 8 295 28 300 92" fill="none" stroke="currentColor" strokeWidth="2.2" strokeDasharray="2 8" strokeLinecap="round"/>
        <path d="M142 54 C126 27 145 10 170 18 C195 10 214 27 198 54 L194 70 L146 70 Z" fill="none" stroke="currentColor" strokeWidth="3.2" strokeLinejoin="round"/>
        <path d="M145 65 L195 65 M149 68 L153 78 L187 78 L191 68" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M64 111 C82 82 98 82 116 108 M276 111 C258 82 242 82 224 108" fill="none" stroke="currentColor" strokeWidth="2.5"/>
        {[0,1,2,3,4].map((n) => <ellipse key={`l${n}`} cx={75+n*9} cy={104-n*3} rx="9" ry="4" transform={`rotate(-38 ${75+n*9} ${104-n*3})`} fill="none" stroke="currentColor" strokeWidth="2"/>)}
        {[0,1,2,3,4].map((n) => <ellipse key={`r${n}`} cx={265-n*9} cy={104-n*3} rx="9" ry="4" transform={`rotate(38 ${265-n*9} ${104-n*3})`} fill="none" stroke="currentColor" strokeWidth="2"/>)}
      </svg>
      <div className="brand-wordmark">Pawon <span>See T</span></div>
      <div className="brand-phone"><Phone size={12}/> {settings.business_phone || DEFAULT_SETTINGS.business_phone}</div>
      <div className="brand-social">
        <span className="social-f">f</span><span>{settings.facebook_handle || DEFAULT_SETTINGS.facebook_handle}</span>
        <Instagram size={13}/><span>{settings.instagram_handle || DEFAULT_SETTINGS.instagram_handle}</span>
      </div>
    </div>
  );
}

function App() {
  const [session, setSession] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    supabase.auth.getSession().then(({ data }) => {
      if (alive) {
        setSession(data.session);
        setAuthLoading(false);
      }
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
    });
    return () => {
      alive = false;
      subscription.unsubscribe();
    };
  }, []);

  if (authLoading) return <FullScreenLoading label="Menyiapkan Pawon See T..." />;
  if (!session) return <AuthScreen />;
  return <WorkspaceGate key={session.user.id} session={session} onSignOut={() => supabase.auth.signOut()} />;
}

function FullScreenLoading({ label }) {
  return <div className="loading-screen"><div className="loading-brand">Pawon <b>See T</b></div><div className="spinner"/><p>{label}</p></div>;
}

function AuthScreen() {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function submit(event) {
    event.preventDefault();
    setBusy(true); setError(""); setMessage("");
    try {
      if (mode === "signup") {
        const { data, error: signError } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { emailRedirectTo: window.location.href.split("#")[0] },
        });
        if (signError) throw signError;
        if (!data.session) {
          setMessage("Akun berhasil didaftarkan. Silakan cek email untuk konfirmasi, lalu masuk kembali dan gunakan kode undangan Pawon See T.");
        } else {
          setMessage("Akun berhasil dibuat. Lanjutkan dengan kode undangan Pawon See T.");
        }
      } else {
        const { error: signError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (signError) throw signError;
      }
    } catch (err) {
      setError(err.message || "Terjadi kesalahan. Coba lagi.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-screen">
      <div className="auth-panel">
        <div className="auth-brand"><BrandMark /></div>
        <div className="auth-heading">
          <span className="eyebrow">RUANG ADMIN</span>
          <h1>{mode === "login" ? "Selamat datang kembali" : "Buat akun admin"}</h1>
          <p>Kelola jadwal, pesanan, menu, dan pembayaran dalam satu tempat.</p>
        </div>
        <div className="auth-tabs">
          <button className={mode === "login" ? "active" : ""} onClick={() => {setMode("login");setError("");setMessage("");}}>Masuk</button>
          <button className={mode === "signup" ? "active" : ""} onClick={() => {setMode("signup");setError("");setMessage("");}}>Daftar akun</button>
        </div>
        <form onSubmit={submit} className="form-stack">
          <label>Email admin<input type="email" autoComplete="email" required value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="nama@email.com"/></label>
          <label>Kata sandi<input type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} minLength="6" required value={password} onChange={(e)=>setPassword(e.target.value)} placeholder="Minimal 6 karakter"/></label>
          {error && <div className="alert alert-error"><AlertCircle size={17}/>{error}</div>}
          {message && <div className="alert alert-success"><CheckCircle2 size={17}/>{message}</div>}
          <button className="btn btn-primary btn-full" disabled={busy}>{busy ? "Memproses..." : mode === "login" ? "Masuk ke Pawon See T" : "Buat akun"}</button>
        </form>
        <p className="auth-footnote">Akses hanya untuk admin yang memiliki kode undangan.</p>
      </div>
      <div className="auth-side">
        <div className="auth-side-copy">
          <span className="eyebrow light">PAWON SEE T</span>
          <h2>Setiap pesanan tercatat. Setiap tanggal terpantau.</h2>
          <p>Kalender pesanan bulanan membantu Bunda melihat jadwal catering dan jumlah box tanpa harus membuka catatan satu per satu.</p>
        </div>
        <div className="auth-side-decoration"><CalendarDays size={120} strokeWidth={0.8}/></div>
      </div>
    </div>
  );
}

function WorkspaceGate({ session, onSignOut }) {
  const [membership, setMembership] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadMembership = useCallback(async () => {
    setLoading(true); setError("");
    const { data, error: queryError } = await supabase
      .from("workspace_members")
      .select("workspace_id, display_name, role")
      .eq("user_id", session.user.id)
      .maybeSingle();
    if (queryError) setError(queryError.message);
    setMembership(data || null);
    setLoading(false);
  }, [session.user.id]);

  useEffect(() => { loadMembership(); }, [loadMembership]);

  if (loading) return <FullScreenLoading label="Memeriksa akses admin..." />;
  if (!membership) return <InviteScreen user={session.user} onClaimed={loadMembership} onSignOut={onSignOut} error={error}/>;
  return <WorkspaceApp session={session} membership={membership} onSignOut={onSignOut}/>;
}

function InviteScreen({ user, onClaimed, onSignOut, error: membershipError }) {
  const [code, setCode] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(membershipError || "");

  async function claim(event) {
    event.preventDefault(); setBusy(true); setError("");
    try {
      const { error: rpcError } = await supabase.rpc("claim_workspace_invite", {
        p_code: code.trim(),
        p_display_name: displayName.trim() || "Admin",
      });
      if (rpcError) throw rpcError;
      await onClaimed();
    } catch (err) {
      setError(err.message || "Kode undangan tidak dapat digunakan.");
    } finally { setBusy(false); }
  }

  return (
    <div className="invite-screen">
      <div className="invite-card">
        <div className="invite-logo"><BrandMark/></div>
        <span className="eyebrow">SATU LANGKAH LAGI</span>
        <h1>Hubungkan akun ke Pawon See T</h1>
        <p>Akun <b>{user.email}</b> belum terhubung ke ruang admin. Masukkan kode undangan yang diberikan pemilik.</p>
        <form onSubmit={claim} className="form-stack">
          <label>Nama yang ditampilkan<input value={displayName} onChange={(e)=>setDisplayName(e.target.value)} placeholder="Contoh: Admin / Bunda"/></label>
          <label>Kode undangan<input value={code} onChange={(e)=>setCode(e.target.value)} required placeholder="Masukkan kode undangan"/></label>
          {error && <div className="alert alert-error"><AlertCircle size={17}/>{error}</div>}
          <button className="btn btn-primary btn-full" disabled={busy}>{busy ? "Memeriksa kode..." : "Hubungkan akun"}</button>
        </form>
        <button className="text-button centered" onClick={onSignOut}><LogOut size={15}/> Keluar dari akun</button>
      </div>
    </div>
  );
}

function WorkspaceApp({ session, membership, onSignOut }) {
  const [workspaceId] = useState(membership.workspace_id);
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [menus, setMenus] = useState([]);
  const [packages, setPackages] = useState([]);
  const [packageItems, setPackageItems] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [page, setPage] = useState(() => new URLSearchParams(window.location.search).get("page") || "calendar");
  const [selectedDate, setSelectedDate] = useState(() => new URLSearchParams(window.location.search).get("date") || jakartaToday());
  const [editingOrder, setEditingOrder] = useState(null);
  const [detailOrder, setDetailOrder] = useState(null);
  const [paymentOrder, setPaymentOrder] = useState(null);
  const [noteOrder, setNoteOrder] = useState(null);
  const [toast, setToast] = useState("");
  const [error, setError] = useState("");

  const notify = (message) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 3200);
  };

  const loadData = useCallback(async (quiet = false) => {
    if (quiet) setRefreshing(true); else setLoading(true);
    setError("");
    try {
      const [settingsRes, menusRes, packagesRes, packageItemsRes, ordersRes] = await Promise.all([
        supabase.from("app_settings").select("*").eq("workspace_id", workspaceId).maybeSingle(),
        supabase.from("menu_items").select("*").eq("workspace_id", workspaceId).order("sort_order"),
        supabase.from("packages").select("*").eq("workspace_id", workspaceId).order("sort_order"),
        supabase.from("package_items").select("*").eq("workspace_id", workspaceId).order("created_at"),
        supabase.from("orders").select("*").eq("workspace_id", workspaceId).order("event_date", { ascending: true }),
      ]);
      for (const result of [settingsRes, menusRes, packagesRes, packageItemsRes, ordersRes]) {
        if (result.error) throw result.error;
      }
      const baseOrders = ordersRes.data || [];
      let groups = [], items = [], payments = [];
      const ids = baseOrders.map((o) => o.id);
      if (ids.length) {
        const [groupsRes, itemsRes, paymentsRes] = await Promise.all([
          supabase.from("order_groups").select("*").eq("workspace_id", workspaceId).in("order_id", ids).order("sort_order"),
          supabase.from("order_items").select("*").eq("workspace_id", workspaceId).in("order_id", ids).order("sort_order"),
          supabase.from("payments").select("*").eq("workspace_id", workspaceId).in("order_id", ids).order("payment_date"),
        ]);
        for (const result of [groupsRes, itemsRes, paymentsRes]) if (result.error) throw result.error;
        groups = groupsRes.data || []; items = itemsRes.data || []; payments = paymentsRes.data || [];
      }
      const itemByGroup = {};
      items.forEach((item) => {
        itemByGroup[item.order_group_id] ||= [];
        itemByGroup[item.order_group_id].push(item);
      });
      const groupByOrder = {};
      groups.forEach((group) => {
        groupByOrder[group.order_id] ||= [];
        groupByOrder[group.order_id].push({ ...group, items: itemByGroup[group.id] || [] });
      });
      const paymentByOrder = {};
      payments.forEach((payment) => {
        paymentByOrder[payment.order_id] ||= [];
        paymentByOrder[payment.order_id].push(payment);
      });
      setSettings({ ...DEFAULT_SETTINGS, ...(settingsRes.data || {}) });
      setMenus(menusRes.data || []);
      setPackages(packagesRes.data || []);
      setPackageItems(packageItemsRes.data || []);
      setOrders(baseOrders.map((order) => ({
        ...order,
        groups: groupByOrder[order.id] || [],
        payments: paymentByOrder[order.id] || [],
      })));
    } catch (err) {
      setError(err.message || "Gagal memuat data Pawon See T.");
    } finally {
      setLoading(false); setRefreshing(false);
    }
  }, [workspaceId]);

  useEffect(() => { loadData(); }, [loadData]);

  useEffect(() => {
    const channel = supabase.channel(`pawon-${workspaceId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "orders", filter: `workspace_id=eq.${workspaceId}` }, () => loadData(true))
      .on("postgres_changes", { event: "*", schema: "public", table: "payments", filter: `workspace_id=eq.${workspaceId}` }, () => loadData(true))
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [workspaceId, loadData]);

  const navigate = (nextPage) => {
    setPage(nextPage);
    const url = new URL(window.location.href);
    url.searchParams.set("page", nextPage);
    url.searchParams.set("date", selectedDate);
    window.history.replaceState({}, "", url);
  };

  const changeSelectedDate = (date) => {
    setSelectedDate(date);
    const url = new URL(window.location.href);
    url.searchParams.set("date", date);
    window.history.replaceState({}, "", url);
  };

  const activeOrders = orders.filter((o) => o.confirmation_status !== "cancelled");
  const navItems = [
    { id: "calendar", label: "Kalender", icon: CalendarDays },
    { id: "orders", label: "Pesanan", icon: ClipboardList },
    { id: "menu", label: "Menu & Harga", icon: Utensils },
    { id: "reminders", label: "Pengingat", icon: Bell },
    { id: "reports", label: "Laporan", icon: BarChart3 },
  ];

  const saveOrder = async (orderPayload, groupsPayload, orderId) => {
    const { data, error: saveError } = await supabase.rpc("save_order_bundle", {
      p_workspace_id: workspaceId,
      p_order: orderPayload,
      p_groups: groupsPayload,
      p_order_id: orderId || null,
    });
    if (saveError) throw saveError;
    await loadData(true);
    setEditingOrder(null);
    setDetailOrder(null);
    notify(orderId ? "Pesanan berhasil diperbarui." : "Pesanan berhasil disimpan.");
    return data;
  };

  const savePayment = async (order, payment) => {
    const { error: paymentError } = await supabase.from("payments").insert({
      workspace_id: workspaceId,
      order_id: order.id,
      amount: Number(payment.amount),
      payment_date: payment.payment_date ? new Date(`${payment.payment_date}T12:00:00+07:00`).toISOString() : new Date().toISOString(),
      payment_method: payment.payment_method,
      reference: payment.reference || null,
      notes: payment.notes || null,
      recorded_by: session.user.id,
    });
    if (paymentError) throw paymentError;
    await loadData(true);
    setPaymentOrder(null);
    setDetailOrder(null);
    notify("Pembayaran berhasil dicatat.");
  };

  const updateOrder = async (orderId, changes, successMessage) => {
    const { error: updateError } = await supabase.from("orders").update(changes).eq("id", orderId).eq("workspace_id", workspaceId);
    if (updateError) throw updateError;
    await loadData(true);
    setDetailOrder(null);
    notify(successMessage);
  };

  if (loading) return <FullScreenLoading label="Memuat kalender dan pesanan..." />;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand"><BrandMark settings={settings}/></div>
        <div className="sidebar-caption">MENU UTAMA</div>
        <nav className="sidebar-nav">
          {navItems.map((item) => <button key={item.id} className={page === item.id ? "active" : ""} onClick={() => navigate(item.id)}><item.icon size={19}/><span>{item.label}</span>{item.id === "reminders" && (activeOrders.filter(o=>o.confirmation_status==="awaiting_dp" && o.event_date===addDays(jakartaToday(),2)).length > 0) && <i className="nav-dot"/>}</button>)}
        </nav>
        <div className="sidebar-bottom">
          <button className={page === "settings" ? "active" : ""} onClick={() => navigate("settings")}><Settings size={19}/><span>Pengaturan</span></button>
          <div className="sidebar-user"><div className="avatar">{(membership.display_name || "A").slice(0,1).toUpperCase()}</div><div><b>{membership.display_name || "Admin"}</b><small>{session.user.email}</small></div></div>
          <button className="logout-button" onClick={onSignOut}><LogOut size={17}/> Keluar</button>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="mobile-brand"><span>Pawon <b>See T</b></span></div>
          <div className="topbar-date"><span className="today-label">HARI INI</span><b>{formatDate(jakartaToday(), { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</b></div>
          <div className="topbar-actions">
            <button className="icon-button" aria-label="Muat ulang" onClick={() => loadData(true)}><RefreshCw size={18} className={refreshing ? "spin" : ""}/></button>
            <button className="btn btn-primary top-add" onClick={() => setEditingOrder({ mode: "new" })}><Plus size={17}/> Tambah pesanan</button>
          </div>
        </header>

        {error && <div className="global-error"><AlertCircle size={16}/>{error}<button onClick={()=>setError("")}><X size={14}/></button></div>}

        <div className="page-content">
          {page === "calendar" && <CalendarPage orders={orders} selectedDate={selectedDate} onSelectDate={changeSelectedDate} onAddOrder={(date)=>setEditingOrder({mode:"new",eventDate:date})} onOpenOrder={setDetailOrder} />}
          {page === "orders" && <OrdersPage orders={orders} onOpenOrder={setDetailOrder} onAddOrder={()=>setEditingOrder({mode:"new"})}/>}
          {page === "menu" && <MenuPage workspaceId={workspaceId} menus={menus} packages={packages} packageItems={packageItems} reload={()=>loadData(true)} notify={notify}/>}
          {page === "reminders" && <RemindersPage orders={orders} onOpenOrder={setDetailOrder} />}
          {page === "reports" && <ReportsPage orders={orders} />}
          {page === "settings" && <SettingsPage workspaceId={workspaceId} user={session.user} settings={settings} onSaved={(next)=>{setSettings(next);notify("Pengaturan berhasil disimpan.");}} notify={notify}/>}
        </div>
      </main>

      <nav className="mobile-nav">
        {navItems.slice(0,5).map((item) => <button key={item.id} className={page===item.id?"active":""} onClick={()=>navigate(item.id)}><item.icon size={19}/><span>{item.label === "Menu & Harga" ? "Menu" : item.label}</span></button>)}
        <button className={page==="settings"?"active":""} onClick={()=>navigate("settings")}><MoreHorizontal size={19}/><span>Lainnya</span></button>
      </nav>

      {editingOrder && <OrderEditorModal
        initialOrder={editingOrder.id ? orders.find(o=>o.id===editingOrder.id) : null}
        defaultDate={editingOrder.eventDate || selectedDate}
        menus={menus.filter(m=>m.is_active)}
        packages={packages.filter(p=>p.is_active)}
        packageItems={packageItems}
        onClose={()=>setEditingOrder(null)}
        onSave={saveOrder}
      />}
      {detailOrder && <OrderDetailModal
        order={orders.find(o=>o.id===detailOrder.id) || detailOrder}
        onClose={()=>setDetailOrder(null)}
        onEdit={(order)=>{setDetailOrder(null);setEditingOrder(order);}}
        onPayment={(order)=>setPaymentOrder(order)}
        onNote={(order)=>setNoteOrder(order)}
        onCancel={async (order)=>{if(window.confirm("Batalkan pesanan ini? Pesanan tetap tersimpan di arsip.")){try{await updateOrder(order.id,{confirmation_status:"cancelled"},"Pesanan dibatalkan.");}catch(e){notify(e.message);}}}}
        onPrepChange={async (order,status)=>{try{await updateOrder(order.id,{preparation_status:status},"Status persiapan diperbarui.");}catch(e){notify(e.message);}}}
      />}
      {paymentOrder && <PaymentModal order={orders.find(o=>o.id===paymentOrder.id) || paymentOrder} onClose={()=>setPaymentOrder(null)} onSave={savePayment}/>}
      {noteOrder && <NoteModal order={orders.find(o=>o.id===noteOrder.id) || noteOrder} settings={settings} onClose={()=>setNoteOrder(null)}/>}
      {toast && <div className="toast"><CheckCircle2 size={17}/>{toast}</div>}
    </div>
  );
}

function PageHeading({ eyebrow, title, description, action }) {
  return <div className="page-heading"><div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1>{description && <p>{description}</p>}</div>{action}</div>;
}

function CalendarPage({ orders, selectedDate, onSelectDate, onAddOrder, onOpenOrder }) {
  const [monthDate, setMonthDate] = useState(() => {
    const [y,m] = selectedDate.split("-").map(Number);
    return new Date(y, m - 1, 1);
  });
  useEffect(() => {
    const [y,m] = selectedDate.split("-").map(Number);
    if (monthDate.getFullYear() !== y || monthDate.getMonth() !== m-1) setMonthDate(new Date(y,m-1,1));
  }, [selectedDate]);
  const monthLabel = new Intl.DateTimeFormat("id-ID", { month: "long", year: "numeric" }).format(monthDate);
  const cells = getMonthDays(monthDate);
  const today = jakartaToday();
  const dayOrders = orders.filter(o=>o.event_date===selectedDate && o.confirmation_status!=="cancelled");
  const dayBoxes = dayOrders.reduce((s,o)=>s+orderBoxes(o),0);
  const dayValue = dayOrders.reduce((s,o)=>s+orderTotal(o),0);
  const marked = new Set(orders.filter(o=>o.confirmation_status!=="cancelled").map(o=>o.event_date));
  const weekday = ["Min","Sen","Sel","Rab","Kam","Jum","Sab"];

  function moveMonth(amount) {
    const next = new Date(monthDate.getFullYear(), monthDate.getMonth()+amount, 1);
    setMonthDate(next);
    const y = next.getFullYear(), m = String(next.getMonth()+1).padStart(2,"0");
    const d = String(Math.min(Number(selectedDate.slice(8,10)), new Date(next.getFullYear(),next.getMonth()+1,0).getDate())).padStart(2,"0");
    onSelectDate(`${y}-${m}-${d}`);
  }

  return (
    <div className="calendar-layout">
      <div className="calendar-main">
        <PageHeading eyebrow="JADWAL CATERING" title="Kalender pesanan" description="Pilih tanggal untuk melihat pesanan dan jumlah box." action={<button className="btn btn-primary desktop-add" onClick={()=>onAddOrder(selectedDate)}><Plus size={17}/> Pesanan baru</button>}/>
        <section className="calendar-card">
          <div className="calendar-toolbar">
            <div><h2>{monthLabel}</h2><p>Lingkaran maroon menandakan ada pesanan</p></div>
            <div className="month-controls"><button className="icon-button" onClick={()=>moveMonth(-1)}><ChevronLeft size={19}/></button><button className="today-button" onClick={()=>{const now=jakartaToday();onSelectDate(now);setMonthDate(new Date(Number(now.slice(0,4)),Number(now.slice(5,7))-1,1));}}>Hari ini</button><button className="icon-button" onClick={()=>moveMonth(1)}><ChevronRight size={19}/></button></div>
          </div>
          <div className="calendar-grid">
            {weekday.map((day)=><div key={day} className="weekday">{day}</div>)}
            {cells.map((day,index)=>{
              if(!day) return <div key={`blank-${index}`} className="calendar-day empty"/>;
              const date = `${monthDate.getFullYear()}-${String(monthDate.getMonth()+1).padStart(2,"0")}-${String(day).padStart(2,"0")}`;
              const hasOrders = marked.has(date);
              const isSelected = selectedDate===date;
              const isToday = today===date;
              return <button key={date} className={`calendar-day ${isSelected?"selected":""} ${isToday?"is-today":""}`} onClick={()=>onSelectDate(date)}>
                <span className="day-number">{day}</span>
                {hasOrders && <i className="day-dot"/>}
              </button>;
            })}
          </div>
          <div className="calendar-legend"><span><i className="legend-dot"/> Ada pesanan</span><span><i className="legend-today"/> Hari ini</span></div>
        </section>
      </div>

      <aside className="selected-day-panel">
        <div className="selected-day-head">
          <div><span className="eyebrow">TANGGAL DIPILIH</span><h2>{formatDate(selectedDate,{weekday:"long",day:"numeric",month:"long"})}</h2></div>
          <button className="add-circle" aria-label="Tambah pesanan" onClick={()=>onAddOrder(selectedDate)}><Plus size={20}/></button>
        </div>
        <div className="day-stats">
          <div><span>Total pesanan</span><b>{numberFormat(dayOrders.length)}</b></div>
          <div><span>Total box</span><b>{numberFormat(dayBoxes)} <small>box</small></b></div>
          <div><span>Nilai pesanan</span><b>{money(dayValue)}</b></div>
        </div>
        <div className="selected-order-list">
          <div className="list-title"><b>Daftar pesanan</b><span>{dayOrders.length} pesanan</span></div>
          {dayOrders.length ? dayOrders.map(order=><OrderCard key={order.id} order={order} onClick={()=>onOpenOrder(order)}/>) : <div className="empty-state compact"><div className="empty-icon"><CalendarDays size={24}/></div><b>Belum ada pesanan</b><p>Tanggal ini masih kosong. Tambahkan pesanan jika ada pelanggan baru.</p><button className="btn btn-outline btn-small" onClick={()=>onAddOrder(selectedDate)}><Plus size={15}/> Tambah pesanan</button></div>}
        </div>
      </aside>
    </div>
  );
}

function OrderCard({ order, onClick }) {
  const status = paymentLabel(order);
  return (
    <button className="order-card" onClick={onClick}>
      <div className="order-card-top"><b>{order.customer_name}</b><span className={`status-pill ${status==="Belum DP"?"status-warning":status==="Dibatalkan"?"status-muted":status==="Lunas"?"status-success":"status-info"}`}>{status}</span></div>
      <div className="order-card-meta"><span><Package size={14}/>{numberFormat(orderBoxes(order))} box</span>{order.event_time && <span><Clock3 size={14}/>{String(order.event_time).slice(0,5)}</span>}</div>
      <p className="order-card-menu">{menuSummary(order) || "Menu belum ditambahkan"}</p>
      <div className="order-card-bottom"><span>{prepLabel(order.preparation_status)}</span><b>{money(orderTotal(order))}</b></div>
    </button>
  );
}

function OrdersPage({ orders, onOpenOrder, onAddOrder }) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("active");
  const [sort, setSort] = useState("asc");
  const filtered = orders.filter(order=>{
    const text = `${order.customer_name} ${order.customer_phone||""} ${order.invoice_number||""}`.toLowerCase();
    const matchText = text.includes(search.toLowerCase());
    const matchFilter = filter==="all" ? true : filter==="active" ? order.confirmation_status!=="cancelled" : filter==="cancelled" ? order.confirmation_status==="cancelled" : filter==="awaiting_dp" ? paymentLabel(order)==="Belum DP" : filter==="paid" ? ["Sudah DP","Lunas"].includes(paymentLabel(order)) : true;
    return matchText && matchFilter;
  }).sort((a,b)=>sort==="asc"?a.event_date.localeCompare(b.event_date):b.event_date.localeCompare(a.event_date));

  return <div className="page-stack">
    <PageHeading eyebrow="DATA PELANGGAN" title="Semua pesanan" description="Cari, periksa, dan ubah pesanan kapan saja." action={<button className="btn btn-primary" onClick={onAddOrder}><Plus size={17}/> Tambah pesanan</button>}/>
    <div className="toolbar-card">
      <div className="search-box"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Cari nama, nomor HP, atau nomor nota..."/></div>
      <div className="toolbar-selects"><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="active">Pesanan aktif</option><option value="all">Semua pesanan</option><option value="awaiting_dp">Belum DP</option><option value="paid">Sudah DP / Lunas</option><option value="cancelled">Dibatalkan</option></select><select value={sort} onChange={e=>setSort(e.target.value)}><option value="asc">Tanggal terdekat</option><option value="desc">Tanggal terbaru</option></select></div>
    </div>
    <div className="orders-list">
      {filtered.length ? filtered.map(order=><OrderCard key={order.id} order={order} onClick={()=>onOpenOrder(order)}/>) : <div className="empty-state"><div className="empty-icon"><ClipboardList size={26}/></div><b>Pesanan tidak ditemukan</b><p>Coba ubah kata pencarian atau filter.</p></div>}
    </div>
  </div>;
}

function OrderEditorModal({ initialOrder, defaultDate, menus, packages, packageItems, onClose, onSave }) {
  const [customerName, setCustomerName] = useState(initialOrder?.customer_name || "");
  const [customerPhone, setCustomerPhone] = useState(initialOrder?.customer_phone || "");
  const [eventDate, setEventDate] = useState(initialOrder?.event_date || defaultDate || jakartaToday());
  const [eventTime, setEventTime] = useState(String(initialOrder?.event_time || "").slice(0,5));
  const [deliveryType, setDeliveryType] = useState(initialOrder?.delivery_type || "delivery");
  const [deliveryAddress, setDeliveryAddress] = useState(initialOrder?.delivery_address || "");
  const [deliveryFee, setDeliveryFee] = useState(String(initialOrder?.delivery_fee || 0));
  const [discount, setDiscount] = useState(String(initialOrder?.discount_amount || 0));
  const [notes, setNotes] = useState(initialOrder?.notes || "");
  const [groups, setGroups] = useState(initialOrder?.groups?.length ? initialOrder.groups.map(buildGroupFromOrder) : [{localId:crypto.randomUUID(),packageId:"",boxCount:"1",items:[]}]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const updateGroup = (index, patch) => setGroups(old=>old.map((g,i)=>i===index?{...g,...patch}:g));
  const addGroup = () => setGroups(old=>[...old,{localId:crypto.randomUUID(),packageId:"",boxCount:"1",items:[]}]);
  const removeGroup = (index) => setGroups(old=>old.length===1?old:old.filter((_,i)=>i!==index));

  function choosePackage(index, packageId) {
    const selectedPackage = packages.find(p=>p.id===packageId);
    const defaultItems = packageItems.filter(item=>item.package_id===packageId).map(item=>{
      const menu = menus.find(m=>m.id===item.menu_item_id);
      if(!menu) return null;
      return {
        menu_item_id: menu.id,
        item_name: menu.name,
        unit_price: Number(item.price_override ?? menu.unit_price ?? 0),
        quantity_per_box: Number(item.quantity_per_box || 1),
        charge_type: "per_box",
        is_included: true,
        notes: "",
      };
    }).filter(Boolean);
    updateGroup(index,{packageId,items:defaultItems});
  }

  function toggleMenu(index, menu) {
    const group=groups[index];
    const found=group.items.find(i=>i.menu_item_id===menu.id);
    const packageDefault = packageItems.find(item => item.package_id === group.packageId && item.menu_item_id === menu.id);
    const items=found ? group.items.filter(i=>i.menu_item_id!==menu.id) : [...group.items,{
      menu_item_id:menu.id,item_name:menu.name,
      unit_price:Number(packageDefault?.price_override ?? menu.unit_price ?? 0),
      quantity_per_box:Number(packageDefault?.quantity_per_box || 1),
      charge_type:"per_box",is_included:Boolean(packageDefault?.is_included),notes:""
    }];
    updateGroup(index,{items});
  }

  function setQuantity(index, menuId, value) {
    const group=groups[index];
    updateGroup(index,{items:group.items.map(i=>i.menu_item_id===menuId?{...i,quantity_per_box:Math.max(0.1,Number(value)||1)}:i)});
  }

  const total = groups.reduce((sum,g)=>sum+Number(g.boxCount||0)*priceForGroup(g,packages),0)+Number(deliveryFee||0)-Number(discount||0);
  const totalBoxes = groups.reduce((sum,g)=>sum+Number(g.boxCount||0),0);

  async function submit(event) {
    event.preventDefault(); setBusy(true); setError("");
    try {
      if(!customerName.trim()) throw new Error("Nama pelanggan wajib diisi.");
      if(!eventDate) throw new Error("Tanggal acara wajib dipilih.");
      if(groups.some(g=>!Number(g.boxCount)||Number(g.boxCount)<1)) throw new Error("Jumlah box setiap kelompok harus minimal 1.");
      if(groups.some(g=>!g.items.length)) throw new Error("Setiap kelompok pesanan harus memiliki menu.");
      const orderPayload = {
        customer_name:customerName.trim(),
        customer_phone:customerPhone.trim()||null,
        event_date:eventDate,
        event_time:eventTime||null,
        delivery_type:deliveryType,
        delivery_address:deliveryType==="delivery"?deliveryAddress.trim()||null:null,
        delivery_fee:Number(deliveryFee||0),
        discount_amount:Number(discount||0),
        notes:notes.trim()||null,
        confirmation_status:initialOrder?.confirmation_status||"awaiting_dp",
        preparation_status:initialOrder?.preparation_status||"not_started",
      };
      const groupsPayload=groups.map((g,i)=>groupPayload(g,packages,i));
      await onSave(orderPayload,groupsPayload,initialOrder?.id||null);
    } catch(err) { setError(err.message||"Pesanan gagal disimpan."); }
    finally { setBusy(false); }
  }

  return <div className="modal-backdrop">
    <div className="modal modal-wide">
      <div className="modal-header"><div><span className="eyebrow">{initialOrder?"UBAH DATA":"PESANAN BARU"}</span><h2>{initialOrder?"Edit pesanan":"Tambah pesanan"}</h2></div><button className="icon-button" onClick={onClose}><X/></button></div>
      <form onSubmit={submit} className="modal-body order-form">
        <div className="form-section">
          <h3>Informasi pelanggan</h3>
          <div className="form-grid two">
            <label>Nama pemesan <em>*</em><input required value={customerName} onChange={e=>setCustomerName(e.target.value)} placeholder="Nama pelanggan"/></label>
            <label>Nomor HP<input value={customerPhone} onChange={e=>setCustomerPhone(e.target.value)} placeholder="08xxxxxxxxxx" inputMode="tel"/></label>
            <label>Tanggal acara <em>*</em><input type="date" required value={eventDate} onChange={e=>setEventDate(e.target.value)}/></label>
            <label>Jam acara / pengiriman<input type="time" value={eventTime} onChange={e=>setEventTime(e.target.value)}/></label>
          </div>
        </div>

        <div className="form-section">
          <div className="section-heading-row"><div><h3>Menu dan jumlah box</h3><p>Setiap kelompok dapat memiliki susunan menu dan harga berbeda.</p></div><button type="button" className="btn btn-outline btn-small" onClick={addGroup}><Plus size={15}/> Tambah kelompok</button></div>
          {groups.map((group,index)=>{
            const selectedIds=group.items.map(i=>i.menu_item_id);
            const price=priceForGroup(group,packages);
            const pack=packages.find(p=>p.id===group.packageId);
            return <div className="group-editor" key={group.localId}>
              <div className="group-editor-head"><b>Kelompok {index+1}</b>{groups.length>1&&<button type="button" className="text-button danger" onClick={()=>removeGroup(index)}><X size={15}/> Hapus</button>}</div>
              <div className="form-grid two">
                <label>Pilih paket (opsional)<select value={group.packageId} onChange={e=>choosePackage(index,e.target.value)}><option value="">Pilih menu langsung</option>{packages.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label>
                <label>Banyaknya box<input type="number" min="1" step="1" value={group.boxCount} onChange={e=>updateGroup(index,{boxCount:e.target.value})}/></label>
              </div>
              {pack&&<div className="helper-note"><Package size={15}/> Isi awal mengikuti pengaturan {pack.name}. Menu masih bisa diubah untuk pesanan ini.</div>}
              <div className="menu-picker">
                <div className="picker-title">Pilih isi menu</div>
                {menus.length?menus.map(menu=>{
                  const checked=selectedIds.includes(menu.id);
                  return <label key={menu.id} className={`menu-choice ${checked?"checked":""}`}>
                    <input type="checkbox" checked={checked} onChange={()=>toggleMenu(index,menu)}/>
                    <span className="choice-check">{checked?<Check size={13}/>:null}</span>
                    <span className="choice-name">{menu.name}<small>{menu.category}{menu.description ? ` · ${menu.description}` : ""}</small></span>
                    <b>{money(menu.unit_price)}</b>
                  </label>;
                }):<p className="muted">Belum ada menu aktif. Tambahkan dahulu di Menu & Harga.</p>}
              </div>
              {group.items.length>0&&<div className="selected-menu-summary">
                <b>Menu yang dipilih</b>
                {group.items.map((item,i)=><div className="selected-menu-row" key={`${item.menu_item_id}-${i}`}>
                  <span>{item.item_name}{item.is_included&&<small>Isi paket</small>}</span>
                  <div><span>{money(item.unit_price)}</span><input aria-label={`Jumlah ${item.item_name} per box`} type="number" min="0.1" step="0.1" value={item.quantity_per_box} onChange={e=>setQuantity(index,item.menu_item_id,e.target.value)}/><span>/ box</span></div>
                </div>)}
              </div>}
              <div className="group-price"><span>{numberFormat(Number(group.boxCount||0))} box × {money(price)} / box</span><b>{money(Number(group.boxCount||0)*price)}</b></div>
            </div>;
          })}
        </div>

        <div className="form-section">
          <h3>Pengiriman dan penyesuaian</h3>
          <div className="form-grid two">
            <label>Metode<select value={deliveryType} onChange={e=>setDeliveryType(e.target.value)}><option value="delivery">Diantar</option><option value="pickup">Diambil</option></select></label>
            {deliveryType==="delivery"&&<label>Alamat pengiriman<input value={deliveryAddress} onChange={e=>setDeliveryAddress(e.target.value)} placeholder="Alamat lengkap"/></label>}
            <label>Biaya pengiriman (Rp)<input type="number" min="0" value={deliveryFee} onChange={e=>setDeliveryFee(e.target.value)}/></label>
            <label>Potongan harga (Rp)<input type="number" min="0" value={discount} onChange={e=>setDiscount(e.target.value)}/></label>
          </div>
          <label>Catatan pesanan<textarea rows="2" value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Catatan tambahan untuk pesanan..."/></label>
        </div>

        <div className="order-total-preview">
          <div><span>Total box</span><b>{numberFormat(totalBoxes)} box</b></div>
          <div><span>Total pesanan</span><strong>{money(total)}</strong></div>
          {!initialOrder&&<small>Status awal: Belum DP. Pesanan belum dianggap terkonfirmasi sampai pembayaran dicatat.</small>}
        </div>
        {error&&<div className="alert alert-error"><AlertCircle size={16}/>{error}</div>}
        <div className="modal-footer"><button type="button" className="btn btn-ghost" onClick={onClose}>Batal</button><button className="btn btn-primary" disabled={busy}>{busy?<span className="spinner-inline"/>:<Save size={16}/>} {busy?"Menyimpan...":"Simpan pesanan"}</button></div>
      </form>
    </div>
  </div>;
}

function OrderDetailModal({ order, onClose, onEdit, onPayment, onNote, onCancel, onPrepChange }) {
  if(!order) return null;
  const status=paymentLabel(order);
  return <div className="modal-backdrop">
    <div className="modal">
      <div className="modal-header"><div><span className="eyebrow">DETAIL PESANAN</span><h2>{order.customer_name}</h2><p className="muted">{order.invoice_number || "Nomor nota dibuat otomatis"}</p></div><button className="icon-button" onClick={onClose}><X/></button></div>
      <div className="modal-body detail-body">
        <div className="detail-summary"><div><span>Tanggal acara</span><b>{formatDate(order.event_date)}</b></div><div><span>Jumlah box</span><b>{numberFormat(orderBoxes(order))} box</b></div><div><span>Total pesanan</span><b>{money(orderTotal(order))}</b></div></div>
        <div className="detail-line"><span><Phone size={15}/> Nomor HP</span><b>{order.customer_phone||"—"}</b></div>
        <div className="detail-line"><span><Clock3 size={15}/> Jam</span><b>{order.event_time?String(order.event_time).slice(0,5):"Belum diatur"}</b></div>
        <div className="detail-line"><span><Truck size={15}/> Pengiriman</span><b>{order.delivery_type==="pickup"?"Diambil":"Diantar"}</b></div>
        {order.delivery_address&&<div className="detail-line"><span><MapPin size={15}/> Alamat</span><b>{order.delivery_address}</b></div>}
        <div className="detail-menu-list"><h3>Menu pesanan</h3>{(order.groups||[]).map((group,i)=><div className="detail-group" key={group.id}><div><b>{numberFormat(group.box_count)} box</b><span>{(group.items||[]).map(item=>item.item_name).join(", ")}</span></div><strong>{money(Number(group.box_count)*Number(group.base_price_per_box))}</strong></div>)}</div>
        {order.notes&&<div className="detail-note"><b>Catatan</b><p>{order.notes}</p></div>}
        <div className="payment-summary">
          <div><span>Status pembayaran</span><b className={`status-pill ${status==="Belum DP"?"status-warning":status==="Lunas"?"status-success":status==="Dibatalkan"?"status-muted":"status-info"}`}>{status}</b></div>
          <div><span>Sudah dibayar</span><b>{money(paidTotal(order))}</b></div>
          <div><span>Sisa pembayaran</span><b>{money(outstanding(order))}</b></div>
          {(order.payments||[]).length>0&&<div className="payment-history"><b>Riwayat pembayaran</b>{order.payments.map(p=><div key={p.id}><span>{formatDate(dateFromTimestamp(p.payment_date),{day:"numeric",month:"short",year:"numeric"})} · {p.payment_method}</span><b>{money(p.amount)}</b></div>)}</div>}
        </div>
        <div className="prep-control"><label>Status persiapan<select value={order.preparation_status} onChange={e=>onPrepChange(order,e.target.value)}><option value="not_started">Belum diproses</option><option value="preparing">Diproses</option><option value="ready">Siap</option><option value="completed">Selesai</option></select></label></div>
        <div className="detail-actions">
          <button className="btn btn-outline" onClick={()=>onEdit(order)}><Edit3 size={16}/> Edit</button>
          <button className="btn btn-outline" onClick={()=>onNote(order)}><ReceiptText size={16}/> Buat nota</button>
          {order.confirmation_status!=="cancelled"&&<button className="btn btn-primary" onClick={()=>onPayment(order)}><Wallet size={16}/> Catat pembayaran</button>}
        </div>
        {order.confirmation_status!=="cancelled"&&<button className="text-button danger centered" onClick={()=>onCancel(order)}>Batalkan pesanan secara manual</button>}
        {order.confirmation_status==="cancelled"&&<div className="alert alert-muted">Pesanan ini sudah dibatalkan dan tidak dihitung sebagai pesanan aktif.</div>}
      </div>
    </div>
  </div>;
}

function PaymentModal({ order, onClose, onSave }) {
  const [amount,setAmount]=useState(String(Math.max(0,outstanding(order))));
  const [paymentDate,setPaymentDate]=useState(jakartaToday());
  const [method,setMethod]=useState("transfer");
  const [reference,setReference]=useState("");
  const [notes,setNotes]=useState("");
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");
  async function submit(e){
    e.preventDefault();setBusy(true);setError("");
    try{
      if(Number(amount)<=0)throw new Error("Nominal pembayaran harus lebih dari 0.");
      await onSave(order,{amount,payment_date:paymentDate,payment_method:method,reference,notes});
    }catch(err){setError(err.message||"Pembayaran gagal disimpan.");}
    finally{setBusy(false);}
  }
  return <div className="modal-backdrop"><div className="modal modal-small">
    <div className="modal-header"><div><span className="eyebrow">PEMBAYARAN</span><h2>Catat pembayaran</h2><p className="muted">{order.customer_name}</p></div><button className="icon-button" onClick={onClose}><X/></button></div>
    <form className="modal-body form-stack" onSubmit={submit}>
      <div className="payment-balance"><span>Sisa pembayaran</span><b>{money(outstanding(order))}</b></div>
      <label>Nominal diterima (Rp)<input type="number" min="1" required value={amount} onChange={e=>setAmount(e.target.value)}/></label>
      <label>Tanggal pembayaran<input type="date" required value={paymentDate} onChange={e=>setPaymentDate(e.target.value)}/></label>
      <label>Metode pembayaran<select value={method} onChange={e=>setMethod(e.target.value)}><option value="transfer">Transfer</option><option value="cash">Tunai</option><option value="qris">QRIS</option><option value="other">Lainnya</option></select></label>
      <label>Referensi / nomor bukti<input value={reference} onChange={e=>setReference(e.target.value)} placeholder="Opsional"/></label>
      <label>Catatan<textarea rows="2" value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Contoh: DP awal"/></label>
      {error&&<div className="alert alert-error"><AlertCircle size={16}/>{error}</div>}
      <div className="modal-footer"><button type="button" className="btn btn-ghost" onClick={onClose}>Batal</button><button className="btn btn-primary" disabled={busy}>{busy?"Menyimpan...":"Simpan pembayaran"}</button></div>
    </form>
  </div></div>;
}

function MenuPage({ workspaceId, menus, packages, packageItems, reload, notify }) {
  const [tab,setTab]=useState("menus");
  const [menuEditor,setMenuEditor]=useState(null);
  const [packageEditor,setPackageEditor]=useState(null);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");

  async function saveMenu(values){
    setBusy(true);setError("");
    try{
      const payload={workspace_id:workspaceId,name:values.name.trim(),category:values.category.trim()||"Lauk",unit_price:Number(values.unit_price||0),unit_label:"porsi",description:values.description||null,is_active:true};
      const result=values.id
        ? await supabase.from("menu_items").update(payload).eq("id",values.id).eq("workspace_id",workspaceId)
        : await supabase.from("menu_items").insert(payload);
      if(result.error)throw result.error;
      await reload();setMenuEditor(null);notify("Menu berhasil disimpan.");
    }catch(err){setError(err.message);}
    finally{setBusy(false);}
  }

  async function toggleMenu(menu){
    const {error:err}=await supabase.from("menu_items").update({is_active:!menu.is_active}).eq("id",menu.id).eq("workspace_id",workspaceId);
    if(err)notify(err.message);else{await reload();notify(menu.is_active?"Menu dinonaktifkan.":"Menu diaktifkan.");}
  }

  async function savePackage(values){
    setBusy(true);setError("");
    try{
      const payload={workspace_id:workspaceId,name:values.name.trim(),base_price_per_box:Number(values.base_price_per_box||0),description:"Atur isi dan harga paket melalui Menu & Harga",is_active:true,sort_order:Number(values.sort_order||0)};
      let packageId=values.id;
      if(packageId){
        const {error:err}=await supabase.from("packages").update(payload).eq("id",packageId).eq("workspace_id",workspaceId);
        if(err)throw err;
      }else{
        const {data,error:err}=await supabase.from("packages").insert(payload).select("id").single();
        if(err)throw err;packageId=data.id;
      }
      const {error:deleteError}=await supabase.from("package_items").delete().eq("workspace_id",workspaceId).eq("package_id",packageId);
      if(deleteError)throw deleteError;
      if(values.menuIds.length){
        const rows=values.menuIds.map(id=>({workspace_id:workspaceId,package_id:packageId,menu_item_id:id,quantity_per_box:1,is_included:true,price_override:null}));
        const {error:insertError}=await supabase.from("package_items").insert(rows);
        if(insertError)throw insertError;
      }
      await reload();setPackageEditor(null);notify("Paket dan isi menunya berhasil disimpan.");
    }catch(err){setError(err.message);}
    finally{setBusy(false);}
  }

  return <div className="page-stack">
    <PageHeading eyebrow="PENGATURAN MENU" title="Menu & harga" description="Atur harga setiap menu dan isi Paket A, B, serta C."/>
    <div className="tab-switch"><button className={tab==="menus"?"active":""} onClick={()=>setTab("menus")}>Daftar menu</button><button className={tab==="packages"?"active":""} onClick={()=>setTab("packages")}>Paket A, B, C</button></div>
    {error&&<div className="alert alert-error"><AlertCircle size={16}/>{error}</div>}
    {tab==="menus"?<>
      <div className="section-heading-row"><div><h2>Daftar menu</h2><p>Harga di sini digunakan untuk menghitung harga per box.</p></div><button className="btn btn-primary" onClick={()=>setMenuEditor({})}><Plus size={17}/> Tambah menu</button></div>
      <div className="menu-management-list">
        {menus.map(menu=><div className={`menu-management-card ${!menu.is_active?"inactive":""}`} key={menu.id}>
          <div className="menu-icon"><Utensils size={18}/></div><div className="menu-info"><b>{menu.name}</b><small>{menu.category}{menu.description?` · ${menu.description}`:""}</small></div><strong>{money(menu.unit_price)}</strong><button className="icon-button small-icon" onClick={()=>setMenuEditor(menu)}><Edit3 size={16}/></button><button className="text-button" onClick={()=>toggleMenu(menu)}>{menu.is_active?"Nonaktifkan":"Aktifkan"}</button>
        </div>)}
      </div>
    </>:<>
      <div className="section-heading-row"><div><h2>Pengaturan paket</h2><p>Pilih menu bawaan untuk setiap paket. Isi paket masih bisa diubah saat membuat pesanan.</p></div><button className="btn btn-primary" onClick={()=>setPackageEditor({})}><Plus size={17}/> Tambah paket</button></div>
      <div className="package-grid">
        {packages.map(pack=>{
          const names=packageItems.filter(i=>i.package_id===pack.id).map(i=>menus.find(m=>m.id===i.menu_item_id)?.name).filter(Boolean);
          return <div className="package-card" key={pack.id}><div className="package-card-top"><div className="package-icon"><Package size={20}/></div><span className="status-pill status-info">Aktif</span></div><h3>{pack.name}</h3><strong>{Number(pack.base_price_per_box)>0?money(pack.base_price_per_box):"Harga otomatis dari menu"}</strong><p>{names.length?names.join(", "):"Isi paket belum diatur."}</p><button className="btn btn-outline btn-full" onClick={()=>setPackageEditor(pack)}><Edit3 size={15}/> Atur paket</button></div>;
        })}
      </div>
    </>}
    {menuEditor!==null&&<MenuItemModal item={menuEditor} onClose={()=>setMenuEditor(null)} onSave={saveMenu} busy={busy}/>}
    {packageEditor!==null&&<PackageModal pack={packageEditor} menus={menus.filter(m=>m.is_active)} packageItems={packageItems} onClose={()=>setPackageEditor(null)} onSave={savePackage} busy={busy}/>}
  </div>;
}

function MenuItemModal({item,onClose,onSave,busy}){
  const [name,setName]=useState(item.name||"");
  const [category,setCategory]=useState(item.category||"Lauk");
  const [price,setPrice]=useState(String(item.unit_price||0));
  const [description,setDescription]=useState(item.description||"");
  return <div className="modal-backdrop"><div className="modal modal-small"><div className="modal-header"><div><span className="eyebrow">DAFTAR MENU</span><h2>{item.id?"Edit menu":"Tambah menu"}</h2></div><button className="icon-button" onClick={onClose}><X/></button></div><form className="modal-body form-stack" onSubmit={e=>{e.preventDefault();onSave({id:item.id,name,category,unit_price:price,description});}}><label>Nama menu<input required value={name} onChange={e=>setName(e.target.value)} placeholder="Contoh: Ayam Goreng"/></label><label>Kategori<input value={category} onChange={e=>setCategory(e.target.value)} placeholder="Lauk / Karbohidrat / Tambahan"/></label><label>Harga per porsi (Rp)<input type="number" min="0" required value={price} onChange={e=>setPrice(e.target.value)}/></label><label>Keterangan<input value={description} onChange={e=>setDescription(e.target.value)} placeholder="Opsional"/></label><div className="modal-footer"><button type="button" className="btn btn-ghost" onClick={onClose}>Batal</button><button className="btn btn-primary" disabled={busy}>{busy?"Menyimpan...":"Simpan menu"}</button></div></form></div></div>;
}

function PackageModal({pack,menus,packageItems,onClose,onSave,busy}){
  const [name,setName]=useState(pack.name||"Paket D");
  const [price,setPrice]=useState(String(pack.base_price_per_box||0));
  const [selected,setSelected]=useState(packageItems.filter(i=>i.package_id===pack.id).map(i=>i.menu_item_id));
  const toggle=(id)=>setSelected(old=>old.includes(id)?old.filter(x=>x!==id):[...old,id]);
  return <div className="modal-backdrop"><div className="modal"><div className="modal-header"><div><span className="eyebrow">PENGATURAN PAKET</span><h2>{pack.id?`Edit ${pack.name}`:"Tambah paket"}</h2></div><button className="icon-button" onClick={onClose}><X/></button></div><form className="modal-body form-stack" onSubmit={e=>{e.preventDefault();onSave({id:pack.id,name,base_price_per_box:price,menuIds:selected,sort_order:pack.sort_order||0});}}><label>Nama paket<input required value={name} onChange={e=>setName(e.target.value)} placeholder="Paket A"/></label><label>Harga dasar per box (Rp)<input type="number" min="0" value={price} onChange={e=>setPrice(e.target.value)}/><small className="field-hint">Isi 0 agar harga otomatis dijumlahkan dari menu yang dipilih.</small></label><div className="picker-title">Isi menu bawaan</div><div className="package-menu-checks">{menus.map(menu=><label key={menu.id} className="menu-choice"><input type="checkbox" checked={selected.includes(menu.id)} onChange={()=>toggle(menu.id)}/><span className="choice-check">{selected.includes(menu.id)?<Check size={13}/>:null}</span><span className="choice-name">{menu.name}<small>{menu.category}{menu.description ? ` · ${menu.description}` : ""}</small></span><b>{money(menu.unit_price)}</b></label>)}</div><div className="modal-footer"><button type="button" className="btn btn-ghost" onClick={onClose}>Batal</button><button className="btn btn-primary" disabled={busy}>{busy?"Menyimpan...":"Simpan paket"}</button></div></form></div></div>;
}

function RemindersPage({orders,onOpenOrder}){
  const today=jakartaToday(),tomorrow=addDays(today,1),dayAfter=addDays(today,2);
  const tomorrowOrders=orders.filter(o=>o.event_date===tomorrow&&o.confirmation_status!=="cancelled");
  const pending=orders.filter(o=>o.event_date===dayAfter&&o.confirmation_status==="awaiting_dp");
  const tomorrowBoxes=tomorrowOrders.reduce((s,o)=>s+orderBoxes(o),0);
  const pendingBoxes=pending.reduce((s,o)=>s+orderBoxes(o),0);
  return <div className="page-stack">
    <PageHeading eyebrow="PUSAT PENGINGAT" title="Pengingat pesanan" description="Pantau pesanan untuk besok dan pesanan yang belum DP."/>
    <div className="reminder-grid">
      <section className="reminder-panel reminder-tomorrow"><div className="reminder-panel-head"><div className="reminder-icon"><BellRing size={20}/></div><div><span className="eyebrow">PENGINGAT H-1</span><h2>Pesanan untuk besok</h2><p>{formatDate(tomorrow,{weekday:"long",day:"numeric",month:"long"})}</p></div></div><div className="reminder-numbers"><div><b>{tomorrowOrders.length}</b><span>Pesanan</span></div><div><b>{numberFormat(tomorrowBoxes)}</b><span>Total box</span></div></div>{tomorrowOrders.length?tomorrowOrders.map(o=><OrderCard key={o.id} order={o} onClick={()=>onOpenOrder(o)}/>):<div className="empty-inline">Belum ada pesanan aktif untuk besok.</div>}</section>
      <section className="reminder-panel reminder-pending"><div className="reminder-panel-head"><div className="reminder-icon"><Wallet size={20}/></div><div><span className="eyebrow">PENGINGAT H-2</span><h2>Belum membayar DP</h2><p>{formatDate(dayAfter,{weekday:"long",day:"numeric",month:"long"})}</p></div></div><div className="reminder-numbers"><div><b>{pending.length}</b><span>Pesanan belum DP</span></div><div><b>{numberFormat(pendingBoxes)}</b><span>Total box</span></div></div>{pending.length?pending.map(o=><OrderCard key={o.id} order={o} onClick={()=>onOpenOrder(o)}/>):<div className="empty-inline">Tidak ada pesanan yang menunggu DP untuk tanggal ini.</div>}</section>
    </div>
    <div className="info-banner"><Bell size={18}/><p>Pengingat H-2 dan H-1 dikirim otomatis sesuai jam pengingat di Pengaturan, jika notifikasi perangkat sudah diaktifkan. Pesanan belum DP tidak dibatalkan otomatis; keputusan pembatalan tetap dilakukan admin.</p></div>
  </div>;
}

function ReportsPage({orders}){
  const today=jakartaToday();
  const [preset,setPreset]=useState("month");
  const [from,setFrom]=useState(dateRangeFor("month",today)[0]);
  const [to,setTo]=useState(dateRangeFor("month",today)[1]);
  const [custom,setCustom]=useState(false);
  useEffect(()=>{if(preset!=="custom"){const range=dateRangeFor(preset,today);setFrom(range[0]);setTo(range[1]);}},[preset,today]);
  const selectedOrders=orders.filter(o=>o.confirmation_status!=="cancelled"&&o.event_date>=from&&o.event_date<=to);
  const boxCount=selectedOrders.reduce((s,o)=>s+orderBoxes(o),0);
  const gross=selectedOrders.reduce((s,o)=>s+orderTotal(o),0);
  const paid=orders.flatMap(o=>o.payments||[]).filter(p=>{const date=dateFromTimestamp(p.payment_date);return date>=from&&date<=to;}).reduce((s,p)=>s+Number(p.amount||0),0);
  const outstandingAmount=selectedOrders.reduce((s,o)=>s+outstanding(o),0);
  const daily={};
  selectedOrders.forEach(o=>{daily[o.event_date] ||= {count:0,boxes:0,value:0};daily[o.event_date].count++;daily[o.event_date].boxes+=orderBoxes(o);daily[o.event_date].value+=orderTotal(o);});
  const days=Object.entries(daily).sort((a,b)=>a[0].localeCompare(b[0]));
  return <div className="page-stack">
    <PageHeading eyebrow="RINGKASAN USAHA" title="Laporan" description="Lihat total pesanan, box, dan pendapatan berdasarkan periode."/>
    <div className="report-filter"><div className="filter-presets">{[["today","Hari ini"],["week","Minggu ini"],["month","Bulan ini"],["year","Tahun ini"],["custom","Pilih tanggal"]].map(([v,l])=><button key={v} className={preset===v?"active":""} onClick={()=>setPreset(v)}>{l}</button>)}</div><div className="date-range-inputs"><label>Dari<input type="date" value={from} onChange={e=>{setFrom(e.target.value);setPreset("custom");}}/></label><label>Sampai<input type="date" value={to} onChange={e=>{setTo(e.target.value);setPreset("custom");}}/></label></div></div>
    <div className="report-period">Periode {formatDate(from,{day:"numeric",month:"short",year:"numeric"})} — {formatDate(to,{day:"numeric",month:"short",year:"numeric"})}</div>
    <div className="stats-grid">
      <StatCard icon={ClipboardList} label="Total pesanan" value={numberFormat(selectedOrders.length)} hint="Berdasarkan tanggal acara"/>
      <StatCard icon={Package} label="Total box" value={numberFormat(boxCount)} hint="Pesanan aktif"/>
      <StatCard icon={CircleDollarSign} label="Pendapatan diterima" value={money(paid)} hint="Berdasarkan tanggal pembayaran" accent/>
      <StatCard icon={Wallet} label="Sisa pembayaran" value={money(outstandingAmount)} hint="Dari pesanan dalam periode"/>
    </div>
    <section className="content-card"><div className="section-heading-row"><div><h2>Rekap per tanggal acara</h2><p>Jumlah pesanan dan box pada setiap tanggal.</p></div><span className="status-pill status-info">{days.length} hari</span></div>{days.length?<div className="report-table-wrap"><table className="report-table"><thead><tr><th>Tanggal acara</th><th>Pesanan</th><th>Total box</th><th>Nilai pesanan</th></tr></thead><tbody>{days.map(([date,data])=><tr key={date}><td>{formatDate(date,{weekday:"short",day:"numeric",month:"short",year:"numeric"})}</td><td>{data.count}</td><td>{numberFormat(data.boxes)} box</td><td>{money(data.value)}</td></tr>)}</tbody></table></div>:<div className="empty-inline">Belum ada pesanan pada periode ini.</div>}</section>
    <div className="report-footnote">Catatan: pendapatan diterima dihitung dari transaksi pembayaran yang dicatat dalam rentang tanggal, bukan dari nilai pesanan yang belum dibayar.</div>
  </div>;
}

function StatCard({icon:Icon,label,value,hint,accent}){
  return <div className={`stat-card ${accent?"stat-accent":""}`}><div className="stat-icon"><Icon size={19}/></div><span>{label}</span><b>{value}</b><small>{hint}</small></div>;
}

function SettingsPage({workspaceId,user,settings,onSaved,notify}){
  const [form,setForm]=useState(settings);
  const [busy,setBusy]=useState(false);
  const [pushBusy,setPushBusy]=useState(false);
  const [pushState,setPushState]=useState("Belum diaktifkan");
  const [error,setError]=useState("");
  useEffect(()=>setForm(settings),[settings]);
  const set=(key,value)=>setForm(old=>({...old,[key]:value}));
  async function save(e){
    e.preventDefault();setBusy(true);setError("");
    try{
      const payload={
        business_name:form.business_name,
        business_phone:form.business_phone,
        business_address:form.business_address,
        facebook_handle:form.facebook_handle,
        instagram_handle:form.instagram_handle,
        invoice_footer:form.invoice_footer,
        timezone:TIME_ZONE,
        notification_time:form.notification_time,
        reminder_tomorrow_enabled:form.reminder_tomorrow_enabled,
        reminder_pending_dp_enabled:form.reminder_pending_dp_enabled,
      };
      const {error:saveError}=await supabase.from("app_settings").update(payload).eq("workspace_id",workspaceId);
      if(saveError)throw saveError;
      onSaved({...settings,...payload});
    }catch(err){setError(err.message||"Pengaturan gagal disimpan.");}
    finally{setBusy(false);}
  }
  async function enablePush(){
    setPushBusy(true);setError("");
    try{
      if(!("serviceWorker" in navigator)||!("PushManager" in window))throw new Error("Browser ini belum mendukung notifikasi web. Coba Chrome di Android.");
      const permission=await Notification.requestPermission();
      if(permission!=="granted")throw new Error("Izin notifikasi belum diberikan.");
      const registration=await navigator.serviceWorker.register(`${import.meta.env.BASE_URL}sw.js`,{scope:import.meta.env.BASE_URL});
      let subscription=await registration.pushManager.getSubscription();
      if(!subscription){
        subscription=await registration.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:urlBase64ToUint8Array(VAPID_PUBLIC_KEY)});
      }
      const json=subscription.toJSON();
      const {error:subError}=await supabase.from("push_subscriptions").upsert({
        workspace_id:workspaceId,
        user_id:user.id,
        endpoint:json.endpoint,
        p256dh:json.keys?.p256dh,
        auth_secret:json.keys?.auth,
        device_label:navigator.userAgent.slice(0,120),
        is_active:true,
      },{onConflict:"endpoint"});
      if(subError)throw subError;
      setPushState("Aktif di perangkat ini");
      notify("Notifikasi Pawon See T berhasil diaktifkan.");
    }catch(err){setError(err.message||"Notifikasi belum dapat diaktifkan.");}
    finally{setPushBusy(false);}
  }
  return <div className="page-stack">
    <PageHeading eyebrow="PENGATURAN" title="Pengaturan usaha" description="Atur identitas nota, jam pengingat, dan notifikasi perangkat."/>
    <form className="settings-layout" onSubmit={save}>
      <section className="content-card settings-card"><div className="card-title-row"><div><h2>Identitas Pawon See T</h2><p>Informasi ini akan tampil otomatis pada nota.</p></div><FileText size={21}/></div>
        <div className="form-stack">
          <label>Nama usaha<input value={form.business_name||""} onChange={e=>set("business_name",e.target.value)}/></label>
          <label>Nomor HP usaha<input value={form.business_phone||""} onChange={e=>set("business_phone",e.target.value)}/></label>
          <label>Alamat usaha<textarea rows="3" value={form.business_address||""} onChange={e=>set("business_address",e.target.value)}/></label>
          <div className="form-grid two"><label>Facebook<input value={form.facebook_handle||""} onChange={e=>set("facebook_handle",e.target.value)}/></label><label>Instagram<input value={form.instagram_handle||""} onChange={e=>set("instagram_handle",e.target.value)}/></label></div>
          <label>Kalimat penutup nota<input value={form.invoice_footer||""} onChange={e=>set("invoice_footer",e.target.value)}/></label>
        </div>
      </section>
      <section className="content-card settings-card"><div className="card-title-row"><div><h2>Pengingat otomatis</h2><p>Zona waktu menggunakan WIB (Asia/Jakarta).</p></div><Bell size={21}/></div>
        <div className="settings-toggle"><div><b>H-1 · Pesanan untuk besok</b><small>Ringkasan pesanan aktif dan total box untuk besok.</small></div><input type="checkbox" checked={form.reminder_tomorrow_enabled!==false} onChange={e=>set("reminder_tomorrow_enabled",e.target.checked)}/></div>
        <div className="settings-toggle"><div><b>H-2 · Pesanan belum DP</b><small>Pengingat untuk pesanan dua hari lagi yang belum membayar DP.</small></div><input type="checkbox" checked={form.reminder_pending_dp_enabled!==false} onChange={e=>set("reminder_pending_dp_enabled",e.target.checked)}/></div>
        <label>Jam pengingat<input type="time" value={String(form.notification_time||"09:00").slice(0,5)} onChange={e=>set("notification_time",e.target.value)}/></label>
        <div className="push-setup"><div><b>Notifikasi perangkat</b><small>Status: {pushState}. Aktifkan agar pengingat bisa muncul sebagai notifikasi di HP.</small></div><button type="button" className="btn btn-outline" onClick={enablePush} disabled={pushBusy}>{pushBusy?"Mengaktifkan...":<><BellRing size={15}/> Aktifkan notifikasi</>}</button></div>
      </section>
      {error&&<div className="alert alert-error"><AlertCircle size={16}/>{error}</div>}
      <div className="settings-save"><button className="btn btn-primary" disabled={busy}>{busy?"Menyimpan...":<><Save size={16}/> Simpan pengaturan</>}</button></div>
    </form>
  </div>;
}

function urlBase64ToUint8Array(base64String) {
  const padding="=".repeat((4-base64String.length%4)%4);
  const base64=(base64String+padding).replace(/-/g,"+").replace(/_/g,"/");
  const raw=window.atob(base64);
  return Uint8Array.from([...raw].map(char=>char.charCodeAt(0)));
}

function NoteModal({order,settings,onClose}){
  const noteRef=useRef(null);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");
  async function download(){
    if(!noteRef.current)return;
    setBusy(true);setError("");
    try{
      const canvas=await html2canvas(noteRef.current,{scale:2,backgroundColor:"#ffffff",useCORS:true,logging:false});
      const link=document.createElement("a");
      link.download=`Nota-Pawon-See-T-${order.invoice_number||order.customer_name.replace(/[^a-z0-9]/gi,"-")}.png`;
      link.href=canvas.toDataURL("image/png");
      link.click();
    }catch(err){setError("Nota belum berhasil dibuat. Coba lagi.");}
    finally{setBusy(false);}
  }
  return <div className="modal-backdrop"><div className="modal modal-note"><div className="modal-header"><div><span className="eyebrow">NOTA DIGITAL</span><h2>Pratinjau nota</h2><p className="muted">Format PNG, mengikuti desain nota Pawon See T.</p></div><button className="icon-button" onClick={onClose}><X/></button></div>
    <div className="note-preview-viewport"><div ref={noteRef}><NoteSheet order={order} settings={settings}/></div></div>
    {error&&<div className="alert alert-error">{error}</div>}
    <div className="modal-footer note-modal-footer"><button className="btn btn-ghost" onClick={onClose}>Tutup</button><button className="btn btn-primary" onClick={download} disabled={busy}>{busy?"Membuat gambar...":<><Download size={16}/> Simpan nota PNG</>}</button></div>
  </div></div>;
}

function NoteSheet({order,settings}){
  const groups=order.groups||[];
  const total=orderTotal(order);
  const paid=paidTotal(order);
  const sisa=outstanding(order);
  const rows=Math.max(8,groups.length+2);
  return <div className="note-sheet">
    <div className="note-header">
      <div className="note-logo"><BrandMark settings={settings}/></div>
      <div className="note-customer">
        <div className="note-title">NOTA PESANAN</div>
        <div><b>Tanggal</b><span>:</span><u>{formatDate(order.event_date,{day:"numeric",month:"long",year:"numeric"})}</u></div>
        <div><b>Nama Pemesan</b><span>:</span><u>{order.customer_name}</u></div>
        <div><b>Hp</b><span>:</span><u>{order.customer_phone||"—"}</u></div>
      </div>
    </div>
    <div className="note-address"><Home size={16}/><span>{settings.business_address||DEFAULT_SETTINGS.business_address}</span></div>
    <div className="note-table-wrap">
      <div className="note-watermark"><BrandMark watermark settings={settings}/></div>
      <table className="note-table">
        <thead><tr><th>BANYAK<br/>NYA</th><th>MENU</th><th>HARGA / BOX</th><th>JUMLAH</th></tr></thead>
        <tbody>
          {groups.map(group=><tr key={group.id}><td>{numberFormat(group.box_count)} box</td><td className="note-menu-cell">{(group.items||[]).map(i=>i.item_name).join(", ")}</td><td>{money(group.base_price_per_box)}</td><td>{money(Number(group.box_count)*Number(group.base_price_per_box))}</td></tr>)}
          {Array.from({length:Math.max(0,rows-groups.length)},(_,i)=><tr key={`empty-${i}`}><td>&nbsp;</td><td></td><td></td><td></td></tr>)}
        </tbody>
      </table>
    </div>
    <div className="note-footer">
      <div className="note-thanks">{settings.invoice_footer||DEFAULT_SETTINGS.invoice_footer}</div>
      <div className="note-signatures"><div>Tanda Terima,<i></i></div><div>Hormat Kami,<i></i></div></div>
      <div className="note-totals">
        <div><b>Total Rp.</b><strong>{money(total)}</strong></div>
        {Number(order.delivery_fee||0)>0&&<div><b>Ongkir</b><span>{money(order.delivery_fee)}</span></div>}
        {Number(order.discount_amount||0)>0&&<div><b>Potongan</b><span>- {money(order.discount_amount)}</span></div>}
        <div><b>DP</b><span>{money(paid)}</span></div>
        <div className="note-balance"><b>Sisa</b><strong>{money(sisa)}</strong></div>
      </div>
    </div>
    <div className="note-bottom-brand">{settings.business_name||"PAWON SEE T"} · {settings.business_phone||DEFAULT_SETTINGS.business_phone}</div>
  </div>;
}

export default App;
